/*** 
 * @Author: hayee
 * @Date: 2022-06-14 15:12:02
 * @LastEditTime: 2022-06-18 12:09:44
 * @LastEditors: hayee
 * @Github: hayeejie
 * @FilePath: \C++_Multiple\Library Commend system\MenuMap.h
 * @ProgramDescription: 
 * @
 */
#pragma once
#include<iostream>
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include <cstring>
using namespace std;

class MenuMap
{
    public:
        void main_menu();        //���˵�
        void Bookmanager_menu(); //������ģ��˵�
        void Report_menu();      //����ģ��˵�
};
