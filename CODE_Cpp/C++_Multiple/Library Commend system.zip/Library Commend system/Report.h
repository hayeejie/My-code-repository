/*** 
 * @Author: hayee
 * @Date: 2022-06-14 15:11:02
 * @LastEditTime: 2022-06-17 23:13:30
 * @LastEditors: hayee
 * @Github: hayeejie
 * @FilePath: \C++_Multiple\Library Commend system\Report.h
 * @ProgramDescription: 
 * @
 */
#pragma once
#include"BookData.h"

class Report
{
    public:
        void menu();
        void report1();
        void report2();
        void report3();
        void report4();
        void report5();
        void report6();
    
};
